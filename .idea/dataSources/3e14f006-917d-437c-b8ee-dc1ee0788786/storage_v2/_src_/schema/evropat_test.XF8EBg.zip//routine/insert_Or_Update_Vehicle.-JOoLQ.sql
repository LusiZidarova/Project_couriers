create
    definer = root@localhost procedure insert_Or_Update_Vehicle(IN vehicle_id_In int, IN brand_In varchar(255),
                                                                IN model_In varchar(255), IN regnumber_In varchar(255),
                                                                IN fuelconsumption_In decimal(5, 2),
                                                                IN office_id_In int(10), IN employee_id_In int(10))
BEGIN
	IF vehicle_id_In IS NULL THEN
		INSERT INTO vehicles (brand, model, reg_number, fuel_consumption, office_id, employee_id)
		VALUES (brand_In, model_In, regnumber_In, fuelconsumption_In, office_id_In, employee_id_In);
        
        SELECT @id := LAST_INSERT_ID();
        
        INSERT INTO vehicles_employee_history (vehicle_id, employee_id, datetime_start, datetime_end)
		VALUES (@id, employee_id_In, NOW(), NULL);
	ELSE
		UPDATE vehicles
		SET brand = brand_In,
			model = model_In,
			reg_number = regnumber_In,
			fuel_consumption = fuelconsumption_In,
			office_id = office_id_In,
			employee_id = employee_id_In
		WHERE id = vehicle_id_In;
        
        UPDATE vehicles_employee_history
        SET datetime_end = NOW()
        WHERE vehicle_id = vehicle_id_In AND datetime_end IS NULL;
        
        INSERT INTO vehicles_employee_history (vehicle_id, employee_id, datetime_start, datetime_end)
		VALUES (vehicle_id_In, employee_id_In, NOW(), NULL);
    end if;
END;

